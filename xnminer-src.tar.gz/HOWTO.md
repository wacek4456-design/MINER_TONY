# How to run — Linux CUDA miner

Full walkthrough: **[README.md](README.md)**

```bash
git clone https://github.com/badnob/xnminer-linux-test.git
cd xnminer-linux-test
chmod +x *.sh && ./install-deps.sh && ./start-miner.sh
```

## 1. Packages

```bash
./install-deps.sh
```

Needs **g++**, **CMake**, **Ninja**, **pkg-config**, **libcurl**.

## 2. NVIDIA

1. Install the NVIDIA driver until `nvidia-smi` lists your GPU.
2. Install the CUDA Toolkit so `nvcc --version` works.

```bash
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}
```

## 3. Start / stop / restart

```bash
./start-miner.sh
./kill-miner.sh
./restart-miner.sh
```

The first start compiles CUDA for **this machine’s compute capability** (for example 75, 86, 89, 90, 120). If you move the folder to another GPU, start again and it rebuilds.

## 4. First-run wallet

1. Enter your `0x` wallet (saved to `miner.ini`).
2. Enter a miner name, or press Enter for `xnminer-xxxxxxxx`.
3. Watch the dashboard (H/s, accepts, temp, VRAM, lanes).
4. **Ctrl+C** or `./kill-miner.sh` stops mining.

There is no pre-filled address, worker, or queued blocks.

## 5. m=100 and lanes

- `force_mine_memory_cost = 100` — GPU always mines easy hashes.
- When the network is also m=100, queued hits flush.
- `max_lanes = 8` — at m=100 the planner uses multiple lanes under the 79% VRAM cap. Other difficulties collapse toward 1 lane.

## Common issues

| Problem | Fix |
|---------|-----|
| Build fails | `./install-deps.sh`; install CUDA Toolkit |
| `nvcc not found` | `export PATH=/usr/local/cuda/bin:$PATH` |
| CUDA start failed | Update the NVIDIA driver; run `./build.sh` on this PC |
| Another instance | `./kill-miner.sh` or delete stale `data/miner.lock` |
| Power limit fails | Run as root, or set `gpu_power_boost_enabled = false` |
