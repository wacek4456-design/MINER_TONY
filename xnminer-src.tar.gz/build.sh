#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD="${ROOT}/build"
mkdir -p "${ROOT}/data"

if ! command -v cmake >/dev/null 2>&1; then
  echo "cmake not found. Run ./install-deps.sh first." >&2
  exit 1
fi

if ! command -v nvcc >/dev/null 2>&1; then
  echo "nvcc not found. Install the NVIDIA CUDA Toolkit and put it on PATH." >&2
  echo "  export PATH=/usr/local/cuda/bin:\$PATH" >&2
  exit 1
fi

detect_arch() {
  if [[ -n "${CMAKE_CUDA_ARCHITECTURES:-}" ]]; then
    echo "${CMAKE_CUDA_ARCHITECTURES}"
    return
  fi
  local caps=()
  if command -v nvidia-smi >/dev/null 2>&1; then
    while IFS= read -r cap; do
      cap="$(echo "${cap}" | tr -d '[:space:]')"
      [[ -z "${cap}" || "${cap}" == "[N/A]" ]] && continue
      if [[ "${cap}" =~ ^([0-9]+)\.([0-9]+)$ ]]; then
        caps+=("${BASH_REMATCH[1]}${BASH_REMATCH[2]}")
      fi
    done < <(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null || true)
  fi
  if [[ ${#caps[@]} -eq 0 ]]; then
    # No GPU visible at build time — emit a fat binary for common cards.
    echo "75;80;86;89;90;120"
    return
  fi
  local uniq=""
  local c
  for c in "${caps[@]}"; do
    case ";${uniq};" in
      *";${c};"*) ;;
      *) uniq="${uniq:+${uniq};}${c}" ;;
    esac
  done
  echo "${uniq}"
}

ARCH="$(detect_arch)"
GEN=()
if command -v ninja >/dev/null 2>&1; then
  GEN=(-G Ninja)
fi

echo "Building xnminer (Linux CUDA) CMAKE_CUDA_ARCHITECTURES=${ARCH}"
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=index,name,compute_cap,memory.total --format=csv || true
fi

rm -f "${BUILD}/CMakeCache.txt"
cmake -S "${ROOT}" -B "${BUILD}" "${GEN[@]}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CUDA_ARCHITECTURES="${ARCH}"
cmake --build "${BUILD}" --parallel

echo "${ARCH}" > "${ROOT}/data/cuda_arch"

echo
if command -v cuobjdump >/dev/null 2>&1 && [[ -x "${BUILD}/bin/xnminer" ]]; then
  echo "Embedded GPU code:"
  cuobjdump -lelf "${BUILD}/bin/xnminer" || true
fi
echo "OK: ${BUILD}/bin/xnminer"
