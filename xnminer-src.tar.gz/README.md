# XenBlocks Miner — Linux (pure CUDA)

A **C++ / CUDA** miner for [XenBlocks](https://xenblocks.io). **No Python.**

It detects **your** NVIDIA GPU, compiles for that card, and starts mining. First run asks for your **EVM wallet**. The queue starts empty — nothing is pre-loaded.

Live dashboard · m=100 harvest · multi-lane CUDA · 79% VRAM cap · CPU sized to your cores · Woodyminer stats

---

## One-liners

Run these **on the Linux PC**, from this folder.

**Start**
```bash
chmod +x *.sh && ./install-deps.sh && ./start-miner.sh
```
After the first successful start, you only need:
```bash
./start-miner.sh
```

**Kill (stop)**
```bash
./kill-miner.sh
```

**Restart**
```bash
./restart-miner.sh
```

**Ctrl+C** in the miner window also stops mining and saves any queued blocks.

---

## What you need

| Item | Why |
|------|-----|
| **Linux** (x86_64) | Ubuntu / Debian is easiest |
| **NVIDIA GPU + driver** | `nvidia-smi` must list your card |
| **CUDA Toolkit** | so `nvcc --version` works (needed to build) |
| **EVM wallet** | `0x` + 40 hex characters — rewards go here |
| Python | **Not used** |

This miner does **not** ship NVIDIA drivers.

---

## Step by step (first time)

### 1. Put the miner on the Linux PC

```bash
git clone https://github.com/badnob/xnminer-linux-test.git
cd xnminer-linux-test
```

Or copy this folder onto the machine and `cd` into it.

### 2. NVIDIA driver

In a terminal:

```bash
nvidia-smi
```

You should see your GPU name. If the command is missing, install the NVIDIA proprietary driver, reboot, and try again.

### 3. CUDA Toolkit

You need `nvcc` (the CUDA compiler):

```bash
nvcc --version
```

If that fails:

1. Install the [CUDA Toolkit](https://developer.nvidia.com/cuda-downloads) for Linux.
2. Then:

```bash
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}
```

### 4. Install build tools and start

```bash
chmod +x *.sh
./install-deps.sh
./start-miner.sh
```

The first start **builds** the miner for **this** GPU. That can take a few minutes. Next starts are fast.

### 5. Enter your wallet (once)

When asked:

1. Paste your **EVM wallet** (`0x` + 40 hex characters). It is saved to `miner.ini`.
2. Type a **miner name**, or press Enter — one is generated for you (`xnminer-xxxxxxxx`).

Mining then starts. You will see a live dashboard: hashrate, accepts, temperature, VRAM, lanes.

### 6. Stop when you are done

- Press **Ctrl+C**, or  
- Run `./kill-miner.sh` from another terminal.

Queued blocks stay in `data/` and are retried next time.

---

## Everyday use

| You want to… | Command |
|--------------|---------|
| Start mining | `./start-miner.sh` |
| Stop mining | `./kill-miner.sh` |
| Stop and start again | `./restart-miner.sh` |
| See the log | `less data/session.log` |
| Change wallet / name | edit `miner.ini`, then restart |

If you move this folder to a **different GPU**, start again — it rebuilds for the new card automatically.

---

## Features (plain language)

### Any NVIDIA GPU

The miner reads your card from `nvidia-smi` and compiles CUDA for **that** compute capability (20-series through 50-series and datacenter cards). You do not pick an architecture by hand.

### No Python

The program is a native binary: `build/bin/xnminer`. Host tools are only for the one-time compile (g++, cmake, nvcc).

### Clean first run

- Empty wallet until **you** type it  
- Empty miner name until you choose one (or auto)  
- Empty block queue — no one else’s finds are in the database  

### Force-mine m=100 (harvest)

The GPU always hashes at **memory cost 100** (the easy / fast setting). Found blocks wait in a **local queue**. When the XenBlocks network is also at m=100, the miner **flushes** the queue to the pool.

### Multi-lane CUDA

At m=100 it runs **up to 8 GPU lanes** in parallel (separate key streams). The VRAM planner splits the same 79% budget across those lanes. A smaller card gets **fewer lanes** automatically if 8 would not fit.

### 79% VRAM cap

By default the miner targets **79% of your GPU’s VRAM**. The rest stays free for the desktop and the driver. Emergency stop if usage climbs too high.

### CPU sized to your cores

It counts **physical cores** and **logical threads**.

- Keygen workers: enough to feed the GPU, **never more than your cores**, 1–2 cores left for the OS  
- Submit/flush workers: scaled to core count (not a fixed 256 on a small CPU)  

No 6-core / 12-thread lock. Small PCs are not oversubscribed.

### Live dashboard

Full-screen console UI:

- Found / accepted / rejected / queued  
- Hashrate  
- GPU: name, VRAM, util %, temperature, power  
- Lane count and batch size  
- Network difficulty (stale/offline aware)  

Use `./start-miner.sh --no-dashboard` for log-only mode.

### Queue and reliability

- Finds are stored in `data/blocks.db` and `data/queue.jsonl`  
- Holds blocks while the network is not at matching m=, during XUNI windows, or if the pool is down  
- **Ctrl+C** / kill saves the queue  
- Only **one** miner instance per folder (`data/miner.lock`)

### Hardware safety

- Temperature warn → shrink batch → pause if still too hot  
- Optional memory-junction temp when the driver reports it  
- Power target as a percent of the card’s max (may need root for `nvidia-smi -pl`)  
- Difficulty-aware power ease when the network is hard  

### Merged block types

One hash stream can produce:

- **XNM** — normal blocks  
- **XBLK** — superblocks  
- **XUNI** — time-window blocks  

XUNI **hunting is off** by default (GPU stays on XNM/XBLK). Any XUNI that is already queued still flushes in the XUNI time window.

### Wallet and remote stats

- First-run wallet saved to `miner.ini`  
- Optional on-chain balance display  
- **[Woodyminer](https://woodyminer.com)** upload on by default (hashrate / accepts while you are away)  
- Optional XenBlockScan events (off by default)

### Single-card select

`device_id = 0` uses the first NVIDIA GPU. Change it in `miner.ini` if you have more than one.

---

## After first start — `miner.ini`

Created from `miner.ini.example`. Common knobs:

```ini
[account]
address = 0xYourWallet...
worker  = my-rig

[mining]
force_mine_memory_cost = 100   # keep this for harvest
xuni_mining_enabled = false

[efficiency]
target_vram_pct = 79.0         # VRAM cap for YOUR card
max_gpu_temp_c = 85
warn_gpu_temp_c = 80

[cuda]
device_id = 0
max_lanes = 8                  # at m=100; planner may use fewer
keygen_threads = 0             # 0 = auto from CPU cores
```

Leave `keygen_threads = 0` unless you know you want a fixed number.

---

## What you should see

| Check | Where |
|-------|--------|
| Hashrate | Dashboard H/s |
| Accepts | Accepted counters |
| Lanes | Dashboard / log (`CUDA lanes: …`) |
| GPU + CPU | Printed at start (`GPU  … sm_XX`, `CPU  N cores / M threads`) |
| Log | `data/session.log` |
| Away from the PC | [woodyminer.com](https://woodyminer.com) |

---

## If something goes wrong

| Problem | Fix |
|---------|-----|
| `python` / pip mentioned | Ignore — this miner does not use Python |
| `nvcc not found` | Install CUDA Toolkit; `export PATH=/usr/local/cuda/bin:$PATH` |
| `cmake` / `g++` missing | `./install-deps.sh` |
| `nvidia-smi` missing | Install NVIDIA driver, reboot |
| Build fails | Driver + CUDA Toolkit versions should match; retry `./build.sh` |
| CUDA start failed | Update driver; run `./start-miner.sh` on **this** machine (rebuilds for this GPU) |
| Another miner running | `./kill-miner.sh` — or delete stale `data/miner.lock` |
| Power limit failed | Normal without root; mining still runs. Or `gpu_power_boost_enabled = false` |
| Wrong wallet | Edit `miner.ini` → `[account] address = 0x...` then restart |
| Window closed | Use `./start-miner.sh`; log is in `data/session.log` |

---

## Files (you can ignore the rest)

```
start-miner.sh      Start (builds if needed)
kill-miner.sh       Stop
restart-miner.sh    Stop then start
install-deps.sh     One-time host packages
build.sh            Compile for this GPU
miner.ini.example   Template (copied to miner.ini on first run)
src/                C++ host
vendor/             CUDA Argon2id kernels
data/               Logs and queue (local only — not published)
```

**Privacy:** never commit `miner.ini` or `data/` — they can contain your wallet and finds.

---

## Optional: run as a service

1. Put your wallet in `miner.ini` first (no prompt under systemd).  
2. Copy `scripts/xnminer.service` to `/etc/systemd/system/` and set `WorkingDirectory`.  
3. `sudo systemctl enable --now xnminer`

---

Happy mining.
