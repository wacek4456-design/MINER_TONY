#!/usr/bin/env bash
# Start the miner. Builds for this machine's GPU the first time (or if the GPU changed).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"
BIN="${ROOT}/build/bin/xnminer"

detect_arch() {
  if [[ -n "${CMAKE_CUDA_ARCHITECTURES:-}" ]]; then
    echo "${CMAKE_CUDA_ARCHITECTURES}"
    return
  fi
  local caps=()
  if command -v nvidia-smi >/dev/null 2>&1; then
    while IFS= read -r cap; do
      cap="$(echo "${cap}" | tr -d '[:space:]')"
      [[ -z "${cap}" || "${cap}" == "[N/A]" ]] && continue
      if [[ "${cap}" =~ ^([0-9]+)\.([0-9]+)$ ]]; then
        caps+=("${BASH_REMATCH[1]}${BASH_REMATCH[2]}")
      fi
    done < <(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null || true)
  fi
  if [[ ${#caps[@]} -eq 0 ]]; then
    echo "75;80;86;89;90;120"
    return
  fi
  local uniq="" c
  for c in "${caps[@]}"; do
    case ";${uniq};" in
      *";${c};"*) ;;
      *) uniq="${uniq:+${uniq};}${c}" ;;
    esac
  done
  echo "${uniq}"
}

need_build=0
if [[ ! -x "${BIN}" ]]; then
  need_build=1
else
  current="$(detect_arch)"
  built="$(tr -d ' \r\n' < "${ROOT}/data/cuda_arch" 2>/dev/null || true)"
  if [[ -z "${built}" || "${built}" != "${current}" ]]; then
    echo "GPU architecture changed (${built:-none} -> ${current}) — rebuilding."
    need_build=1
  fi
fi

if [[ "${need_build}" -eq 1 ]]; then
  echo "Building pure CUDA miner for this GPU..."
  "${ROOT}/build.sh"
fi

if [[ ! -f "${ROOT}/miner.ini" ]]; then
  cp "${ROOT}/miner.ini.example" "${ROOT}/miner.ini"
  echo "Created miner.ini (empty wallet — you will be asked for your 0x address)."
fi

mkdir -p "${ROOT}/data"
exec "${BIN}" "$@"
